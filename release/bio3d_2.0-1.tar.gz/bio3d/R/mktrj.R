`mktrj` <-
function(x, ...) {
  UseMethod("mktrj")
}

