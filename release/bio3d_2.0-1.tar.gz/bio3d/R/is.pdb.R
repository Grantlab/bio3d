is.pdb <- function(x)
  inherits(x, "pdb")