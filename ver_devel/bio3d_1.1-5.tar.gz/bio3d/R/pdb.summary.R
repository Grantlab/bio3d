"pdb.summary" <-
function(pdb) {
  print.pdb(pdb)
}

